﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Library
{

	/// <summary>
	/// Класс "Ограничение ИЛИ"
	/// </summary>
	public class PaiM
	{
		PictureBox picture = new PictureBox();
		public PaiM(PictureBox picture)
		{
			this.picture = picture;
		}
		/// <summary>
		/// Метод для создания "Ограничение ИЛИ"
		/// </summary>
		/// <param name="e"></param>
		/// <param name="e2"></param>
		/// <returns></returns>
		public PictureBox Ris(MouseEventArgs e, MouseEventArgs e2)
		{
			float x1 = e.X;
			float y1 = e.Y;
			float x2 = e2.X;
			float y2 = e2.Y;
            String drawString = "Текст";
            Font drawFont = new Font("Arial", 9);
            SolidBrush drawBrush = new SolidBrush(Color.Black);
            PointF drawPoint = new PointF(x1, y1);
            Graphics gr = picture.CreateGraphics();
			gr.DrawString(drawString, drawFont, drawBrush, drawPoint);
            gr.Dispose();
			return picture;
        }
		/// <summary>
		/// Метод для перерисовки "Ограничение ИЛИ"
		/// </summary>
		/// <param name="e"></param>
		/// <param name="e2"></param>
		/// <returns></returns>
		public PictureBox Paint(MouseEventArgs e, MouseEventArgs e2)
		{
			Graphics gr = picture.CreateGraphics();
			float x1 = e.X;
			float y1 = e.Y;
			float x2 = e2.X;
			float y2 = e2.Y;
			Pen pe = new Pen(Color.Black, 5);
			pe.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
			pe.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
			gr.DrawLine(pe, x1, y1, x2, y2);
			pe.Dispose();
			return picture;
		}
	}
}
